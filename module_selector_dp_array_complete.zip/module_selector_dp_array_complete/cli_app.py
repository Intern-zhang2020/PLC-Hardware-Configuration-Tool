from __future__ import annotations

import time

from selector_core import SelectorError, select_modules_and_save


def read_nonnegative_int(prompt: str) -> int:
    while True:
        try:
            value = int(input(prompt).strip())
        except ValueError:
            print("请输入整数。")
            continue

        if value < 0:
            print("不能输入负数。")
            continue

        return value


def read_name(prompt: str) -> str:
    while True:
        name = input(prompt).strip()
        if not name:
            print("名称不能为空。")
            continue
        if len(name) > 200:
            print("名称不能超过 200 个字符。")
            continue
        return name


def main():
    print("二维数组动态规划 I/O 模块最低价格选型（含历史比较）")
    print("=" * 68)

    requirement_name = read_name("需求名称：")
    req_ai = read_nonnegative_int("AI 需求：")
    req_ao = read_nonnegative_int("AO 需求：")
    req_di = read_nonnegative_int("DI 需求：")
    req_do = read_nonnegative_int("DO 需求：")

    started = time.perf_counter()

    try:
        result = select_modules_and_save(
            requirement_name=requirement_name,
            req_ai=req_ai,
            req_ao=req_ao,
            req_di=req_di,
            req_do=req_do,
        )
    except SelectorError as exc:
        print(f"\n选型失败：{exc}")
        return

    elapsed = time.perf_counter() - started

    print("\n推荐方案")
    print("=" * 90)

    for row in result["rows"]:
        print(
            f"{row['category']} | "
            f"{row['module_name']} × {row['count']} | "
            f"单价 {row['unit_price']:.2f} | "
            f"小计 {row['subtotal']:.2f}"
        )
        print(
            f"  AI={row['ai']}，AO={row['ao']}，"
            f"固定DI={row['fixed_di']}，"
            f"固定DO={row['fixed_do']}，"
            f"DIO→DI={row['dio_to_di']}，"
            f"DIO→DO={row['dio_to_do']}，"
            f"备用DIO={row['dio_spare']}"
        )

    actual = result["actual"]

    print("-" * 90)
    print(f"名称：{result['requirement_name']}")
    print(f"历史记录 ID：{result['history_id']}")
    print(
        f"实际满足：AI={actual['ai']}，"
        f"AO={actual['ao']}，"
        f"DI={actual['di']}，"
        f"DO={actual['do']}"
    )
    print(f"AIO784 选中数量：{result['selected_aio784_count']}")
    print(f"总价格：{result['total_price']:.2f}")
    print(f"模块总数：{result['module_count']}")

    closest = result.get("closest_history")
    if closest is None:
        print("历史比较：这是第一条历史记录。")
    else:
        old = closest["requirement"]
        delta = closest["delta"]
        print(
            "最接近历史需求："
            f"{closest['requirement_name']}，"
            f"AI={old['ai']}，AO={old['ao']}，"
            f"DI={old['di']}，DO={old['do']}"
        )
        print(
            f"差值：ΔAI={delta['ai']:+d}，ΔAO={delta['ao']:+d}，"
            f"ΔDI={delta['di']:+d}，ΔDO={delta['do']:+d}"
        )
        print(
            f"归一化距离：{closest['normalized_distance']:.6f}，"
            f"参考相似度：{closest['similarity_percent']:.2f}%"
        )

    print(f"求解用时：{elapsed:.3f} 秒")


if __name__ == "__main__":
    main()
