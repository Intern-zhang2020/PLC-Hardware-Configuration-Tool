# I/O 模块选型：二维数组动态规划完整版

## 本版包含的功能

- `dp[AI][AO]` 使用真正的二维列表保存状态；
- `dp[DI][DO]` 使用真正的二维列表保存状态；
- 不再使用 `best[(ai, ao)]`、`parent[(di, do)]` 这样的字典保存 DP 状态；
- AIO784 同时参与 AI/AO 联合选型；
- DIO 自动分配为 DI、DO 和备用 DIO；
- 优先保证总价格最低，价格相同时模块数量最少；
- GUI 包含名称输入框，AI/AO/DI/DO 间距统一；
- 自动保存历史需求和模块明细；
- 使用 AI/AO/DI/DO 四维归一化欧氏距离查找最接近历史需求；
- 历史数据库采用规范化的主表和明细表。

## 文件说明

```text
selector_core.py          数据库读取、二维数组 DP、历史保存和距离比较
gui_app.py                图形界面
cli_app.py                命令行界面
db_config.json            MySQL 配置
create_history_tables.sql 历史表结构
test_array_dp.py          二维数组 DP 与大状态保护测试
test_aio784.py            AIO784 测试
test_history_distance.py  历史距离测试
```

## 安装

```powershell
python -m pip install -r requirements.txt
```

打开 `db_config.json`，填写 MySQL 密码：

```json
{
    "host": "localhost",
    "user": "root",
    "password": "你的密码",
    "database": "module_db",
    "port": 3306
}
```

## 测试

```powershell
python test_array_dp.py
python test_aio784.py
python test_history_distance.py
```

## 启动 GUI

```powershell
python gui_app.py
```

## 二维数组结构

模拟量使用：

```python
best_cost[ai][ao]
best_count[ai][ao]
parent_ai[ai][ao]
parent_ao[ai][ao]
parent_module[ai][ao]
```

数字量使用：

```python
best_cost[di][do]
best_count[di][do]
parent_di[di][do]
parent_do[di][do]
parent_option[di][do]
```

字典仍用于表示一条模块记录、数据库查询结果和最终汇总；这些不是 DP 状态表。

## 内存保护

二维数组会一次性分配完整状态空间。程序顶部设置：

```python
MAX_ARRAY_DP_STATES = 1_500_000
```

当 `(DI+1) × (DO+1)` 或 `(AI+1) × (AO+1)` 超过该值时，程序会给出错误提示，而不是继续分配内存。

例如 `DI=9000、DO=9000` 需要约 8100 万个状态，因此数组版会主动阻止。修改安全上限可以允许更大状态，但有明显内存风险。

## 历史表

主表：

```text
selection_history
```

模块明细表：

```text
selection_history_module
```

查看简洁历史：

```sql
SELECT * FROM selection_history_overview;
```

查看某次选型的模块：

```sql
SELECT *
FROM selection_history_module_overview
WHERE history_id = 1;
```
